<?php
$return = "Hello";
echo json_encode($return);
//$temp = file_get_contents("http://www.google.com/");
//$temp = "<table><tr><td>hello</td></tr></table>";


?>