<?
$URL="http://". $_SERVER["HTTP_HOST"] . $_SERVER["REQUEST_URI"];
?>

<table style="text-align: left; width: 200px;" border="0"
cellpadding="0" cellspacing="0">
<tbody>
<tr>
<td><a href=
"http://209.85.135.104/translate_c?hl=en&amp;langpair=en%7Cfr&amp;u=<?echo $URL;?>">
<img style="border: 0px solid ; width: 30px; height: 20px;" alt=
"Fran&ccedil;ais/French" src=
"images/frenchflag.jpg"></a></td>
<td><a href=
"http://209.85.135.104/translate_c?hl=en&amp;langpair=en%7Cde&amp;u=<?echo $URL;?>">
<img style="border: 0px solid ; width: 30px; height: 20px;" alt=
"Deutsch/German" src=
"images/germanflag.jpg"></a></td>
<td><a href=
"http://209.85.135.104/translate_c?hl=en&amp;langpair=en%7Cit&amp;u=<?echo $URL;?>">
<img style="border: 0px solid ; width: 30px; height: 20px;" alt=
"Italiano/Italian" src=
"images/italianflag.jpg"></a></td>
<td><a href=
"http://209.85.135.104/translate_c?hl=en&amp;langpair=en%7Cnl&amp;u=<?echo $URL;?>">
<img title="Netherlands/Dutch" style=
"border: 0px solid ; width: 30px; height: 20px;" alt=
"Netherlands/Dutch" src=
"images/flag-netherlands.jpg"></a></td>
<td><a href=
"http://209.85.135.104/translate_c?hl=en&amp;langpair=en%7Ces&amp;u=<?echo $URL;?>">
<img style="border: 0px solid ; width: 30px; height: 20px;" alt=
"Espa&ntilde;ol/Spanish" src=
"images/spanishflag.jpg"></a></td>
<td><a href=
"http://209.85.135.104/translate_c?hl=en&amp;langpair=en%7Cpt&amp;u=<?echo $URL;?>">
<img style="border: 0px solid ; width: 30px; height: 20px;" alt=
"Portugu&ecirc;s/Portuguese" src=
"images/portugeseglag.jpg"></a></td>
</tr>
<tr>
<td><a href=
"http://209.85.135.104/translate_c?hl=en&amp;langpair=en%7Cko&amp;u=<?echo $URL;?>">
<img style="border: 0px solid ; width: 30px; height: 20px;" alt=
"&iacute;&bull;&oelig;&ecirc;&micro;&shy;&igrave;&ndash;&acute;/Korean"
src="images/koreanflag.jpg"></a></td>
<td><a href=
"http://209.85.135.104/translate_c?hl=en&amp;langpair=en%7Czh-CN&amp;u=<?echo $URL;?>">
<img style="border: 0px solid ; width: 30px; height: 20px;" alt=
"&auml;&cedil;&shy;&aelig;&ndash;&Dagger;&iuml;&frac14;&circ;&ccedil;&reg;&euro;&auml;&frac12;&ldquo;&iuml;&frac14;&permil;/Chinese Simplified"
src="images/chineseflag.jpg"></a></td>
<td><a href=
"http://209.85.135.104/translate_c?hl=en&amp;langpair=en%7Cja&amp;u=<?echo $URL;?>">
<img style="border: 0px solid ; width: 30px; height: 20px;" alt=
"&aelig;&mdash;&yen;&aelig;&oelig;&not;&egrave;&ordf;&#382;/Japanese"
src="images/japanflag.jpg"></a></td>
<td><a href=
"http://209.85.135.104/translate_c?hl=en&amp;langpair=en%7Cel&amp;u=<?echo $URL;?>">
<img style="border: 0px solid ; width: 30px; height: 20px;" alt=
"Greek" src="images/greekflag.gif"></a></td>
<td><a href=
"http://209.85.135.104/translate_c?hl=en&amp;langpair=en%7Car&amp;u=<?echo $URL;?>">
<img title="Arabic / UAE" style=
"border: 0px solid ; width: 30px; height: 20px;" alt="Arabic / UAE"
src="images/arabic_flag.bmp"></a></td>
<td><a href=
"http://209.85.135.104/translate_c?hl=en&amp;langpair=en%7Cru&amp;u=<?echo $URL;?>">
<img title="Russia/Russian" style=
"border: 0px solid ; width: 30px; height: 20px;" alt=
"Russia/Russian" src=
"images/russia.gif"></a></td>
</tr>
</table>
