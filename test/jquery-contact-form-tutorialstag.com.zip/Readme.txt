#####################

Advanced jQuery contact form
Version: 1.1

####################

Thanks for downloading my Advanced jQuery contact form. Please download ClassMathGuard.php file from http://www.phpclasses.org/package/3926-PHP-CAPTCHA-validation-using-math-expressions.html and paste it inside the folder where you have the contact.php file


Don't forget to edit the mail settings in contact.php:

$sales_address = "Your @sales address";
$support_address = "Your @support address";
$billing_address = "Your @billing address";